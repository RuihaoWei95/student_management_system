package cm.stu.dao;

import cm.stu.bean.Person;

public interface UserLoginDao {
    Person getLogin(Person person);

    Person checkAccount(Person account);
}
