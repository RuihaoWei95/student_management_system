package cm.stu.dao;

public interface StudentDao {
}
