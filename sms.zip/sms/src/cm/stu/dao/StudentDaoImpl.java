package cm.stu.dao;

public class StudentDaoImpl implements StudentDao{
}
