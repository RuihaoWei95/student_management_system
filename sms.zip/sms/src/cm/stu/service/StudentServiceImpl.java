package cm.stu.service;

public class StudentServiceImpl implements StudentService{
}
