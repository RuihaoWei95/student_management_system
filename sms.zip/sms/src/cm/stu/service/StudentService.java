package cm.stu.service;

public interface StudentService {
}
